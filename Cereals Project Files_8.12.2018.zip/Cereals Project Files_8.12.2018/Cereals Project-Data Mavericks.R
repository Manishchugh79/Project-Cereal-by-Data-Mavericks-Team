install.packages("arrange")
library(arrange)

cereal_asce<- arrange(cereal, calories)
head(cereal_asce)

cereal_desc<-arrange(cereal, desc(calories))
head(cereal_desc)

boxplot(cereal$calories, main="Box Plot of Calories", col = "red")

hist(cereal$calories, xlab="Calories", ylabs="Frequency", main="Histogram of Cereals", col="red")

install.packages("car")
library(car)

install.packages("carData")
library(carData)

install.packages("ggplot2")
library(ggplot2)

scatterplotMatrix(~calories+sugars+carbo+fat|type,
                   data=cereal,
                  main = "Calories vs Sugar, Carbo & Fat")

scatterplotMatrix(~calories+protein+vitamins+fiber|type,
                  data=cereal, 
                  main = "Calories vs Protein,Vitamin & Fiber")

a<-table(cereal$mfr)
a
group<-c("A", "G", "K", "N", "P", "Q", "R")
pie(a, labels = group,
    main = "Pie Manufacturers")
