# 6 lowest calorie cereals by using arrange function

library(dplyr)
cereal_ascen<- dplyr::arrange(cereal, calories)
cereal_ascen
head(cereal_ascen)

# 6 highest calorie cereals by using arrange function

library(dplyr)
cereal_desc<- dplyr::arrange(cereal, desc(calories))
cereal_desc
head(cereal_desc)

# Boxplot of calories

boxplot(cereal$calories, main="Box Plot of Calories", col = "red")

# Histogram of calories

hist(cereal$calories, xlab="Calories", ylab="Frequency", main="Histogram of Cereals", col="red")

# Scatterplot of calorie vs sugar, calorie vs carb, calorie vs fat

library(car)
scatterplotMatrix(~calories+sugars+carbo+fat|type,
                  data=cereal,
                  main = "Calories vs Sugar, Carbo & Fat")

# Scatterplot of calorie vs protein, calorie vs vitamin, calorie vs fiber

library(car)
scatterplotMatrix(~calories+protein+vitamins+fiber|type,
                  data=cereal, 
                  main = "Calories vs Protein,Vitamin & Fiber")

# Mean and median of calories

mean(cereal$calories)
median(cereal$calories)

# Pie chart of manufacturers

a<-table(cereal$mfr)
a
group<-c("A", "G", "K", "N", "P", "Q", "R")
pie(a, labels = group,
    main = "Pie Manufacturers")

# List of 6 highest rated products

library(dplyr)
cereal_ascen<- dplyr::arrange(cereal, rating)
cereal_ascen
head(cereal_ascen)

# Scatterplot of calories on x-axis and rating on y-axis. 
# Draw a regression line if there is any clear pattern, or else not.

install.packages("ggplot2")
library(ggplot2)

ggplot(data = cereal)+
  geom_point(mapping = aes(x = calories,
                           y = rating))
