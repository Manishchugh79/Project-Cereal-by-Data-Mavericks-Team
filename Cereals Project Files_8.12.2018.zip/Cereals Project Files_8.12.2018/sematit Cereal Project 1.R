
# Mean & Median of calories

mean(cereals_data$calories)

view(cereals_data)

median(cereals_data$calories)


# Scatterplot of calories on x-axis and rating on y-axis. 
# Draw a regression line if there is any clear pattern, or else not.
  

install.packages("ggplot2")
library(ggplot2)

ggplot(data = cereals_data)+
  geom_point(mapping = aes(x = calories,
                           y = rating))


# List of 6 highest rated products

library(dplyr)
cereals_data_desc<- arrange(cereals_data, desc(rating))
head(cereals_data)



